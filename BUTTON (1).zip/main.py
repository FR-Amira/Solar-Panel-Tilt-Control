from machine import Pin
Button = Pin(4,Pin.IN)
Button2 = Pin(26,Pin.IN,Pin.PULL_UP)
counter = 0
counter2 = 10
import time

while 1 :
    Button_state= Button.value()
    Button_state2= Button2.value()

    if Button_state and counter < 9 :
        counter = counter + 1
        print("counter ",counter)
        time.sleep_ms(300)
    
    if not Button_state2 and counter > 0  :
        counter = counter - 1
        print("counter  ",counter)
        time.sleep_ms(300)
