from machine import Pin , PWM
import time

Servo = PWM(Pin(18,Pin.OUT),freq = 50 )

def map(value, in_min, in_max, out_min, out_max):
    value = max(in_min, min(in_max, value))
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def rotate(angle):
    angle = int (map(angle , 0 , 180 , 1500 , 8000))
    Servo.duty_u16(angle)


while 1 : 
     #Servo.duty_u16(1500)  # angle 0 
     # time.sleep(1)
     #Servo.duty_u16(4500)  # angle 90
     #time.sleep(1)
     #Servo.duty_u16(8000)  # angle 180
     #time.sleep(1)

     rotate(180)
     time.sleep(1)
     rotate(90)
     time.sleep(1)
     rotate(0)
     time.sleep(1)
