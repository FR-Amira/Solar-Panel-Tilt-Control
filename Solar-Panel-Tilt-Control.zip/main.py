from machine import Pin , PWM
import time
ButtonCON = Pin(4,Pin.IN)
ButtonDEC = Pin(5,Pin.IN,Pin.PULL_UP)
Servo = PWM(Pin(18,Pin.OUT),freq = 50 )
counter = 0
Seg = [Pin(27,Pin.OUT),
Pin(26,Pin.OUT), 
Pin(14,Pin.OUT), 
Pin(12,Pin.OUT),
Pin(13,Pin.OUT),
Pin(17,Pin.OUT),
Pin(16,Pin.OUT) ]

#for i in range(7):
#  Seg[i].on()

Number = [
  # a b c d e f g
  [1,1,1,1,1,1,0], # 0
  [0,1,1,0,0,0,0], #1
  [1,1,0,1,1,0,1], #2
  [1,1,1,1,0,0,1], #3
  [0,1,1,0,0,1,1], # 4
  [1,0,1,1,0,1,1], #5
  [1,0,1,1,1,1,1], #6
  [1,1,1,0,0,0,0], #7
  [1,1,1,1,1,1,1], #8
  [1,1,1,1,0,1,1] #9
]


def clear_dispy():
  for i in range(7):
    Seg[i].off()

def display(n):
  digit=Number[n]
  for i in range(7):
    Seg[i].value(digit[i])

def map(value, in_min, in_max, out_min, out_max):
    value = max(in_min, min(in_max, value))
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def rotate(angle):
    angle = int (map(angle , 0 , 180 , 1500 , 8000))
    Servo.duty_u16(angle)

while 1 :
    Button_stateCON= ButtonCON.value()
    Button_stateDEC= ButtonDEC.value()

    if Button_stateCON and counter < 9 :
        counter = counter + 1
        print("counter ",counter)
        time.sleep_ms(300)
    
    if not Button_stateDEC and counter > 0  :
        counter = counter - 1
        print("DEcounter  ",counter)
        time.sleep_ms(300)
    
    display(counter)
    rotate(counter * 20 )

    time.sleep_ms(50)

    
